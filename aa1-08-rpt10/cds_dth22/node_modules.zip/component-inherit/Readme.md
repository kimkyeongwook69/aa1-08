# inherit

  Prototype inheritance utility.

## Installation

```
$ component install component/inherit
```

## Example

```js
var inherit = require('inherit');

function Human() {}
function Woman() {}

inherit(Woman, Human);
```

## License

  MIT
